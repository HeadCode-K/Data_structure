package m3;

public class OrderedArray<T extends Comparable<T>> implements PriorityQueue<T> {

	public T[] array;
	private int size;
	
	@SuppressWarnings("unchecked")
	public OrderedArray(int maxSize) {
		array = (T[]) new Comparable[maxSize];
		size = 0;
	}
	
	@Override
	public boolean isEmpty() {
		//
		// FIXME
		//
		return (size == 0);
	}

	@Override
	public void insert(T thing) {
		//
		// FIXME
		//
		int i;
		for(i=0;i<array.length-1;i++){

            if(array[i].compareTo(thing)>0)
                break;
        }
        for(int k=i;k<array.length-1;k++){
        	array[k+1]=array[k];
        	array[i]=thing;
        }
	}
	
	@Override
	public T extractMin() {
		//
		// FIXME
		//
		if (size <= 0) return null;
		return array[--size];
		
	}

}

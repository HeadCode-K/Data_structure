package m3;

import java.util.LinkedList;
import java.util.List;

public class UnorderedList<T extends Comparable<T>> implements PriorityQueue<T> {

	public LinkedList<T> list;
	
	public UnorderedList() {
		list = new LinkedList<T>();
	}
	
	@Override
	public boolean isEmpty() {
		//
		// FIXME
		//
		boolean bool = list.isEmpty();
		if (bool){
			return true;}
		else {
			return false;
		}
	}

	@Override
	public void insert(T thing) {
		
		
		list.add(thing);
	}

	@Override
	public T extractMin() {
		//
		// FIXME
		//
		
		
		
		T min = list.peekFirst();
		if ( min == null) {return null;}
		for (T num : list) 
        {
            if (num.compareTo(min) < 0)
            {
            	min = num;
            }
        }
		list.remove(min);
		return min;
	}
}



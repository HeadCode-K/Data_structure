package simple;

public class Simple {

	private int data;

	/**
	 * Initialize data to -1.
	 */
	public Simple() {
        data = -1;
	}
	
	/**
     * Get value of data.
     * @return data
	 */
	public int getData() {
        // FIXME: replace the following statement to return the
        // appropriate value.
		
        return data;
    }

    /**
     * Set value of data.
     * @param int value to give to instance variable
     */
    public void setData(int value) {
        // FIXME: replace the following statement to set 
        // data equal to value.
        this.data = value;
    }
}

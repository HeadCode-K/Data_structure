Base repository for CSE 247 Studio 2.

Base repository for CSE 247 studios.

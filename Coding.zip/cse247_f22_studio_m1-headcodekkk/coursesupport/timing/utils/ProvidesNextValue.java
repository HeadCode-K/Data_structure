package timing.utils;

public interface ProvidesNextValue {
	
	public int nextValue(int oldValue);

}
